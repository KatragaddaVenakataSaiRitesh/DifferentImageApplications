
import UIKit

class ViewController: UIViewController {
    
    var imageArray: [UIImage] = [UIImage(named: "scene1.jpeg")!,UIImage(named: "scene2.jpeg")!,UIImage(named: "scene3.jpeg")!,UIImage(named: "scene4.jpeg")!,UIImage(named: "scene5.jpeg")!]
    
    @IBOutlet weak var image: UIImageView!
    var i: Int = 0
    var j: Int = 4
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //image.image = imageArray[0]
        
        let rswipe = UISwipeGestureRecognizer(target: self, action: #selector(swipe(_:)))
        rswipe.direction = .right
        view.addGestureRecognizer(rswipe)
        
        
        let lswipe = UISwipeGestureRecognizer(target: self, action: #selector(swipe(_:)))
        lswipe.direction = .left
        view.addGestureRecognizer(lswipe)
        
    }
    
    @objc func swipe(_ sender:UISwipeGestureRecognizer)
    {
        if(sender.direction == .right)
        {
            if(i<5){
                image.image = imageArray[i]
                label.text = String(i+1)
                i+=1
                j=i-1
                
            }
            else if(i==5)
            {
                i=0
            }
            }
        else if(sender.direction == .left)
        {
            
            if(j>=0)
            {
                image.image = imageArray[j]
                label.text = String(j+1)
                j-=1
                i=j+1
            }
            else if(j<0)
            {
                j=4
            }
            
        }
    
    
    }
    
    
}

