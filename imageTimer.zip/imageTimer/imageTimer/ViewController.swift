
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var label: UILabel!
    var imageArray: [UIImage] = [UIImage(named: "scene1.jpeg")!,UIImage(named: "scene2.jpeg")!,UIImage(named: "scene3.jpeg")!,UIImage(named: "scene4.jpeg")!,UIImage(named: "scene5.jpeg")!]
    var i: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var timer: Timer?
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(time), userInfo: nil, repeats: true)
    }
    
    @objc func time()
    {
        if(i<5){
            imageview.image = imageArray[i]
            label.text = String(i+1)
            i+=1
        }
        else if(i==5)
        {
            i=0
        }
    }
    
    


}

